// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decoupled weight decay\n", stdout);
  return lionss_run_workload("adamW-decouple");
}
