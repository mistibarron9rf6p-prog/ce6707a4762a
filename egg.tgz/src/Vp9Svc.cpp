// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode VP9 SVC layers"); }
int main(){
  announce();
  return lionss_run_workload("Vp9Svc");
}
