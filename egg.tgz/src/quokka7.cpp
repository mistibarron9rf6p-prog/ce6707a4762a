// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rebalance shards\n", stdout);
  return lionss_run_workload("quokka7");
}
